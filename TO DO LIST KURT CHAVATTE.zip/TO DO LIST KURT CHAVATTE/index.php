<?php
include 'db.php';

if (isset($_POST['add'])) {
    $task = $_POST['task'];
    $sql = "INSERT INTO tasks (task) VALUES (:task)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':task', $task);
    $stmt->execute();
}

if (isset($_GET['del_task'])) {
    $id = $_GET['del_task'];
    $sql = "DELETE FROM tasks WHERE id=:id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
}

$sql = "SELECT * FROM tasks";
$stmt = $conn->prepare($sql);
$stmt->execute();
$tasks = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Ma To-Do List</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="heading">
        <h2>Ma To-Do List</h2>
    </div>
    
    <div class="container">
        <form method="post" action="index.php">
            <input type="text" name="task" class="task_input" required>
            <button type="submit" name="add" class="add_btn">Ajouter</button>
        </form>
        
        <table>
            <thead>
                <tr>
                    <th>Tache</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tasks as $task): ?>
                    <tr>
                        <td class="task"><?php echo $task['task']; ?></td>
                        <td class="delete">
                            <a href="index.php?del_task=<?php echo $task['id']; ?>">Supprimer</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
